import React, { useState, useEffect } from 'react';
import { BlogPost } from './types/blog';
import { loadPosts, savePosts } from './utils/storage';
import Header from './components/Header';
import PostList from './components/PostList';
import PostEditor from './components/PostEditor';
import PostView from './components/PostView';

type View = 'list' | 'create' | 'post';

function App() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [currentView, setCurrentView] = useState<View>('list');
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState('');

  useEffect(() => {
    const loadedPosts = loadPosts();
    setPosts(loadedPosts);
  }, []);

  const handleSavePost = (post: BlogPost) => {
    const existingIndex = posts.findIndex(p => p.id === post.id);
    let updatedPosts: BlogPost[];
    
    if (existingIndex >= 0) {
      updatedPosts = [...posts];
      updatedPosts[existingIndex] = post;
    } else {
      updatedPosts = [post, ...posts];
    }
    
    setPosts(updatedPosts);
    savePosts(updatedPosts);
    setCurrentView('list');
  };

  const handlePostClick = (post: BlogPost) => {
    setSelectedPost(post);
    setCurrentView('post');
  };

  const handleViewChange = (view: 'list' | 'create') => {
    setCurrentView(view);
    if (view === 'list') {
      setSelectedPost(null);
    }
  };

  const getAllTags = (): string[] => {
    const allTags = posts.flatMap(post => post.tags);
    return Array.from(new Set(allTags)).sort();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        currentView={currentView}
        onViewChange={handleViewChange}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedTag={selectedTag}
        onTagChange={setSelectedTag}
        availableTags={getAllTags()}
      />

      <main>
        {currentView === 'list' && (
          <PostList
            posts={posts}
            searchQuery={searchQuery}
            selectedTag={selectedTag}
            onPostClick={handlePostClick}
          />
        )}

        {currentView === 'create' && (
          <PostEditor
            onSave={handleSavePost}
            onCancel={() => setCurrentView('list')}
          />
        )}

        {currentView === 'post' && selectedPost && (
          <PostView
            post={selectedPost}
            onBack={() => setCurrentView('list')}
          />
        )}
      </main>
    </div>
  );
}

export default App;