import React from 'react';
import { ArrowLeft, Calendar, Clock, Tag, User, Download, ExternalLink } from 'lucide-react';
import { BlogPost } from '../types/blog';
import { formatDate } from '../utils/storage';
import { formatFileSize, getFileIcon, isImageFile } from '../utils/fileUtils';

interface PostViewProps {
  post: BlogPost;
  onBack: () => void;
}

const PostView: React.FC<PostViewProps> = ({ post, onBack }) => {
  const handleFileDownload = (file: any) => {
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderFilePreview = (file: any) => {
    if (isImageFile(file.type)) {
      return (
        <div className="relative group">
          <img
            src={file.url}
            alt={file.name}
            className="w-full h-64 object-cover rounded-lg"
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all rounded-lg flex items-center justify-center">
            <button
              onClick={() => handleFileDownload(file)}
              className="opacity-0 group-hover:opacity-100 bg-white text-gray-700 px-3 py-2 rounded-lg font-medium transition-all hover:bg-gray-100"
            >
              <Download className="h-4 w-4 inline mr-1" />
              Download
            </button>
          </div>
        </div>
      );
    }

    return (
      <div className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
              <ExternalLink className="h-5 w-5 text-gray-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">{file.name}</p>
              <p className="text-sm text-gray-500">{formatFileSize(file.size)}</p>
            </div>
          </div>
          <button
            onClick={() => handleFileDownload(file)}
            className="text-blue-600 hover:text-blue-700 font-medium text-sm transition-colors"
          >
            Download
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <button
          onClick={onBack}
          className="inline-flex items-center text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to posts
        </button>
      </div>

      <article className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-8">
          <header className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              {post.title}
            </h1>
            
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-6">
              <div className="flex items-center">
                <User className="h-4 w-4 mr-1" />
                <span className="font-medium">{post.author}</span>
              </div>
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                {formatDate(post.createdAt)}
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                {post.readTime} min read
              </div>
            </div>

            {post.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {post.tags.map(tag => (
                  <span
                    key={tag}
                    className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
                  >
                    <Tag className="h-3 w-3 mr-1" />
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </header>

          <div className="prose prose-lg max-w-none mb-8">
            <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
              {post.content}
            </div>
          </div>

          {post.files.length > 0 && (
            <div className="border-t border-gray-200 pt-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Attachments ({post.files.length})
              </h3>
              <div className="grid gap-4 sm:grid-cols-2">
                {post.files.map(file => (
                  <div key={file.id}>
                    {renderFilePreview(file)}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </article>
    </div>
  );
};

export default PostView;