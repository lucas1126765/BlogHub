import React from 'react';
import { Calendar, Clock, Tag, FileText, Image, Video, Music } from 'lucide-react';
import { BlogPost } from '../types/blog';
import { formatDate } from '../utils/storage';
import { getFileIcon } from '../utils/fileUtils';

interface PostCardProps {
  post: BlogPost;
  onClick: () => void;
}

const PostCard: React.FC<PostCardProps> = ({ post, onClick }) => {
  const getFileTypeIcon = (type: string) => {
    const iconName = getFileIcon(type);
    switch (iconName) {
      case 'image': return Image;
      case 'video': return Video;
      case 'music': return Music;
      default: return FileText;
    }
  };

  return (
    <article 
      className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-lg hover:border-blue-300 transition-all duration-300 cursor-pointer group"
      onClick={onClick}
    >
      <div className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors line-clamp-2">
          {post.title}
        </h2>
        
        <p className="text-gray-600 mb-4 line-clamp-3">
          {post.excerpt}
        </p>

        {post.files.length > 0 && (
          <div className="flex items-center space-x-2 mb-4">
            <div className="flex -space-x-1">
              {post.files.slice(0, 3).map((file, index) => {
                const IconComponent = getFileTypeIcon(file.type);
                return (
                  <div
                    key={file.id}
                    className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center border-2 border-white"
                  >
                    <IconComponent className="h-4 w-4 text-gray-600" />
                  </div>
                );
              })}
            </div>
            {post.files.length > 3 && (
              <span className="text-sm text-gray-500">
                +{post.files.length - 3} more
              </span>
            )}
          </div>
        )}

        {post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {post.tags.slice(0, 3).map(tag => (
              <span
                key={tag}
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                <Tag className="h-3 w-3 mr-1" />
                {tag}
              </span>
            ))}
            {post.tags.length > 3 && (
              <span className="text-xs text-gray-500">
                +{post.tags.length - 3} more
              </span>
            )}
          </div>
        )}

        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-1" />
              {formatDate(post.createdAt)}
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {post.readTime} min read
            </div>
          </div>
          <div className="text-right">
            <p className="font-medium text-gray-700">{post.author}</p>
          </div>
        </div>
      </div>
    </article>
  );
};

export default PostCard;