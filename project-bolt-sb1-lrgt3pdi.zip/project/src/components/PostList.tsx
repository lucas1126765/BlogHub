import React from 'react';
import { BlogPost } from '../types/blog';
import PostCard from './PostCard';
import { FileText } from 'lucide-react';

interface PostListProps {
  posts: BlogPost[];
  searchQuery: string;
  selectedTag: string;
  onPostClick: (post: BlogPost) => void;
}

const PostList: React.FC<PostListProps> = ({ 
  posts, 
  searchQuery, 
  selectedTag, 
  onPostClick 
}) => {
  const filteredPosts = posts.filter(post => {
    const matchesSearch = searchQuery === '' || 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTag = selectedTag === '' || post.tags.includes(selectedTag);
    
    return matchesSearch && matchesTag;
  });

  if (filteredPosts.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <FileText className="mx-auto h-16 w-16 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {posts.length === 0 ? 'No posts yet' : 'No posts found'}
          </h3>
          <p className="text-gray-500 max-w-md mx-auto">
            {posts.length === 0 
              ? 'Get started by creating your first blog post. Share your thoughts, upload files, and engage with your audience.'
              : 'Try adjusting your search query or selected tag to find the content you\'re looking for.'
            }
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">
          {searchQuery || selectedTag ? 'Search Results' : 'Latest Posts'}
        </h2>
        <p className="text-gray-600 mt-1">
          {filteredPosts.length} {filteredPosts.length === 1 ? 'post' : 'posts'} found
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredPosts.map(post => (
          <PostCard
            key={post.id}
            post={post}
            onClick={() => onPostClick(post)}
          />
        ))}
      </div>
    </div>
  );
};

export default PostList;