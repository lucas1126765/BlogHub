export interface BlogPost {
  id: string;
  title: string;
  content: string;
  author: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
  files: UploadedFile[];
  excerpt: string;
  readTime: number;
}

export interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  uploadedAt: string;
}

export interface BlogStore {
  posts: BlogPost[];
  searchQuery: string;
  selectedTag: string;
}