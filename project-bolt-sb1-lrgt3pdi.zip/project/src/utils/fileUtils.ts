import { UploadedFile } from '../types/blog';
import { generateId } from './storage';

export const handleFileUpload = (file: File): Promise<UploadedFile> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const uploadedFile: UploadedFile = {
        id: generateId(),
        name: file.name,
        type: file.type,
        size: file.size,
        url: e.target?.result as string,
        uploadedAt: new Date().toISOString()
      };
      resolve(uploadedFile);
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsDataURL(file);
  });
};

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const getFileIcon = (fileType: string): string => {
  if (fileType.startsWith('image/')) return 'image';
  if (fileType.startsWith('video/')) return 'video';
  if (fileType.startsWith('audio/')) return 'music';
  if (fileType.includes('pdf')) return 'file-text';
  if (fileType.includes('document') || fileType.includes('word')) return 'file-text';
  if (fileType.includes('spreadsheet') || fileType.includes('excel')) return 'file-spreadsheet';
  return 'file';
};

export const isImageFile = (fileType: string): boolean => {
  return fileType.startsWith('image/');
};